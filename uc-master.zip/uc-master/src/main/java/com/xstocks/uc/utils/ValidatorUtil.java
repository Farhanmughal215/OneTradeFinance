package com.xstocks.uc.utils;

import org.apache.commons.validator.routines.UrlValidator;

/**
 * @ClassName ValidatorUtil
 * @Description TODO
 * @Author junfudong@xiaomi.com
 * @Date 2023/11/13 13:54
 **/
public class ValidatorUtil {

    private static final UrlValidator urlValidator = new UrlValidator(new String[] {"http", "https"});

    public static boolean url(String url) {
        return urlValidator.isValid(url);
    }
}
