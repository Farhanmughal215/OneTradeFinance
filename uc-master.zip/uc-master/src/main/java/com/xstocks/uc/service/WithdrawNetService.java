package com.xstocks.uc.service;

import com.xstocks.uc.pojo.WithdrawNet;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 提现网络表 服务类
 * </p>
 *
 * @author kevin
 * @since 2024-01-15
 */
public interface WithdrawNetService extends IService<WithdrawNet> {

}
