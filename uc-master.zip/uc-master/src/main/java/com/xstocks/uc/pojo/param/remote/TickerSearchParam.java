package com.xstocks.uc.pojo.param.remote;

import lombok.Data;

@Data
public class TickerSearchParam {
    private String keyword;
    private String type;
}
