package com.xstocks.uc.pojo.enums;

public enum ProviderEnum {
    watchdata,
    getblock
}
