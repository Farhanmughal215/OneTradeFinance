package com.xstocks.uc.pojo.param;

import lombok.Data;

/**
 * @author Kevin
 * @date 2024/3/11 15:48
 * @apiNote
 */
@Data
public class BTraderDetailParam {

    private Integer traderId;

}
