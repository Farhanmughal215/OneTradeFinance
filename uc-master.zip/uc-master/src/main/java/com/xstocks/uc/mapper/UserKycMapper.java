package com.xstocks.uc.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xstocks.uc.pojo.po.UserCollectPO;
import com.xstocks.uc.pojo.po.UserKycPO;

public interface UserKycMapper extends BaseMapper<UserKycPO> {

}




