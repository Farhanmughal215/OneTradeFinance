package com.xstocks.uc.pojo.vo;

import lombok.Data;

/**
 * @ClassName OperatorVO
 * @Description TODO
 * @Author junfudong@xiaomi.com
 * @Date 2023/11/23 9:36
 **/

@Data
public class OperatorVO {
    private Long id;
    private String userName;
}
