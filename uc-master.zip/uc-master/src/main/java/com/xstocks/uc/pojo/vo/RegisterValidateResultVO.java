package com.xstocks.uc.pojo.vo;

import lombok.Data;

@Data
public class RegisterValidateResultVO {
    private Boolean valid;

    private Integer validateType;
}
