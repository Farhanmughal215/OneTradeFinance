package com.xstocks.uc.pojo.enums;

import lombok.Getter;

/**
 * @ClassName NodeEnum
 * @Description TODO
 * @Author firtuss
 * @Date 2022/11/9 14:02
 **/
@Getter
public enum PolygoWebSocketEvEnum {
    status,
    AM,
    A,
    T,
    Q,
    FMV
}
