package com.xstocks.uc.pojo.param.remote;

import lombok.Data;

/**
 * @author Kevin
 * @date 2024/3/18 17:48
 * @apiNote
 */
@Data
public class TraderAddressResult {

    private String address;

    private String path;
}
