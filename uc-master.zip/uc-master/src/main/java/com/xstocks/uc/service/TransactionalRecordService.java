package com.xstocks.uc.service;

import com.xstocks.uc.pojo.TransactionalRecord;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author kevin
 * @since 2024-03-22
 */
public interface TransactionalRecordService extends IService<TransactionalRecord> {

}
