package com.xstocks.uc.service;

import com.xstocks.uc.pojo.po.TunePlanPO;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author firtuss
* @description 针对表【tune_plan(扎针计划)】的数据库操作Service
* @createDate 2023-11-17 19:25:03
*/
public interface TunePlanService extends IService<TunePlanPO> {

}
