package com.xstocks.uc.pojo.param.remote;

import lombok.Data;

/**
 * @ClassName TickerIdParam
 * @Description TODO
 * @Author junfudong@xiaomi.com
 * @Date 2023/11/16 21:42
 **/

@Data
public class TickerIdParam {
    private Long id;
}
